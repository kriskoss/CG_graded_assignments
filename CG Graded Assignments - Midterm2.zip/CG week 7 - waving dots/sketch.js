/*
Unfortunately I run out of time to finish the asignment. I was not able to incorporate new ideas into the project and make wave look properly. I was able to draw the dots and color them using noise. I was also able to use translate and rotate functions to affect the movement of each dot individually. One minor additonal feature that I implemented is the line connecting the original position of each dot and its position after the transformation. I also tried to make the wave look more organic by adding a random component to the angle of rotation. 
*/
///

var amp;
function setup()
{
    createCanvas(500, 500);
    background(255);
    rectMode(CENTER);
    // noiseDetail(1)
    amp = 100
    angle = random(0,360)
}

function draw()
{
    background(255);

    var noOfDots = 20;
    var size = width/noOfDots;

    for (var x = 0; x < noOfDots; x++){
      for (var y = 0; y < noOfDots; y++){
        waves1(x,y,size)
    }
}
}
/*Step 4: 
To generate the wave you need to calculate the phase angle and use rotate() and translate() in your wave() function to animate. 
The angle is calculated using the x and y coordinates as well as the frameCount so that the animation change over time. Make sure you scale the input parameters of the wave function appropriately so that you get organic values out of it. Do not use framerate() to adjust the animation.*/


function wave(_x,_y){ // replace params with the necessary parameters
  
  
}
function createDot(size,c){
  push();
    noStroke()
    fill(c)
    ellipse(0,0,size,size);
  pop();
}


function createNewColor(x,y){
  let f = 0.1
    let fc = frameCount*0.01
    
    let R = noise((x+1)*f, (y+1)*f, fc)*255
    let G = 100 -noise((x+2)*f, (y+2)*f, fc)*50
    let B = (1- noise((x+3)*f, (y+3)*f, fc))*255
    
    let c= color(R,G,B)
    
    return c
}

function drawLine(originX,originY,endX,endY){
  push()
    stroke(color("red"))
    let el_size = 4
    ellipse(originX,originY,el_size,el_size)
    line(originX,originY,endX,endY)
  pop()
}

function waves1(x,y,size ){
  let c = createNewColor(x,y)
  push() // POSITIONING THE DOTS
    translate(x*size,y*size) // POSITIONING THE DOTS
    
    push() // WAVE EFFECT
      wave(x, y); 
      createDot(size/2,c)
    pop() // WAVE EFFECT END
    
  pop() // POSITIONING THE DOTS END

        
}
function wave(x,y){
  shiftV = 0
    shiftH = 50
    mY = map(mouseY,0,height,0.05,0.1)
    let mX = map(mouseX,0,width,0.05,0.01)
    let n = noise(x*mX,y*mY+4,frameCount*0.004)
    
    let nA = noise( + x*0.006,y*0.003+2,frameCount*mX)
        
    // let angleStep = map(nA,0,1,-0.1,0.1)
    
    // angleStep = map(nA,0,1,0.01,0.02)
    // angleStep = constrain(angleStep, 0.1, high)
    angleStep = map(mouseX,0,width,-0.02,0.02) + n*map(mouseY,0,height,-0.05,0.05)
    angle = angle + angleStep
    
    shiftH = map(n,0,1,-amp,amp)
    
    // if (x==0 && y==0){
    //   console.log(angle )
    // }
    rotate(radians(angle))
      drawLine(0,0,shiftH,shiftV)
      translate(shiftH,shiftV)
}





